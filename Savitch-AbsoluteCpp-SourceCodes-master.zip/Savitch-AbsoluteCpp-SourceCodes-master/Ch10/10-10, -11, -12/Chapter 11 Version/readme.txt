This directory is for readers who have already covered Section 11.1 of Chapter 11.
It presents Displays 10.10, 10.11, and 10.12 as three files:
interface file, implementation file, and application file.
This required only very minor rewritting of the displays.

This does not place the class PFArrayD in a namespace, but if you have
read Section 11.2 of Chapter 11, that would be an easy exercise.
