This is Cpp files from Savitch, Absolute Cpp book
Sources are dealed with the book
